#!/bin/bash
python3 morphology.py dict.txt rules.txt test.txt > morphology.trace
