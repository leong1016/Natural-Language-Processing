Q1. Which CADE machine you tested your program on?
A1. CADE lab1-16

Q2. Any known idiosyncracies, problems, or limitations of your program?
A2. No.
