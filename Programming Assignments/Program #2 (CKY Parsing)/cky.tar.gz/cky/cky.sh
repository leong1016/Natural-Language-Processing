#!/bin/bash
python3 cky.py pcfg.txt sentences.txt
python3 cky.py pcfg.txt sentences.txt -prob